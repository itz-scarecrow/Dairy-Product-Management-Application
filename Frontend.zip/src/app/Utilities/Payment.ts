export class Payment{
    id: string = "";
    userid: string = "";
    paymentid: string = "";
    username: string = "";
    paymentmode: string = "";
    paymentstatus: string = "";
    totalPrice: number = 0.0;
}