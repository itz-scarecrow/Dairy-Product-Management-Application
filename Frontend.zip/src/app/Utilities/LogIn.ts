export interface LogIn{
    id:string,
    username: string;
    email: string;
    password: string;
    roles :string;
}