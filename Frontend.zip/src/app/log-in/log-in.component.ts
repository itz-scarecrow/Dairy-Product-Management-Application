import { Component, OnInit } from '@angular/core';
import { LoginServiceService } from '../services/login-service.service';
import { LogIn } from '../Utilities/LogIn';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { CartserviceService } from '../services/cartservice.service';
import { Cart } from '../Utilities/Cart';
import { NotificationService } from '../services/notification.service';
import { Notification } from '../Utilities/Notification';
@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {
  portal: number = 0;
  ver: boolean = false;
  existing: boolean = false;
  username: String = "";
  email: any;
  password: any;
  roles: String = "user";
  details: any;
  existingData:any;
  notiData: any;
  constructor(private router: Router, private logInService: LoginServiceService,private cartService: CartserviceService,private notiService:NotificationService) { }
  ngOnInit(): void {
    this.existingData=JSON.parse(localStorage.getItem('data') || '{}');
    console.log(this.existingData);
    if(this.existingData.length>0){
      if (this.existingData[0].roles === "User") {
        this.router.navigate(["/user/home"]);
      }
      else if (this.existingData[0].roles=== "Admin") {
        this.router.navigate(["/admin/products"]);
      }
      else {
        this.router.navigate(["/delivery/orders"]);
      }
    }
  }

  change(): void {
    this.portal = (this.portal + 1) % 2;
  }
  SignUp() {
    this.logInService.getDeatilsWithUserName(this.email, this.roles).subscribe((data: LogIn[]) => {
      console.log(data);
      if (data.length == 0) {
        this.ver = false;
        this.details = {
          username: this.username,
          email: this.email,
          password: this.password,
          roles: this.roles
        }
        this.logInService.postDetails(this.details).subscribe((data: LogIn) => {
          console.log(data);
          localStorage.setItem("data", JSON.stringify(data));
          this.cartService.getCartData(data.id).subscribe((data: Cart[])=>{
            console.log(data);
            localStorage.setItem('cartLength',JSON.stringify(data.length));
          })
          this.notiService.getNotification(data.id).subscribe((data:Notification[])=>{
            console.log(data);
            localStorage.setItem('notiLength',JSON.stringify(data.length));
            localStorage.setItem("noti",JSON.stringify(data));
          })
          if (this.details.roles === "User") {
            this.router.navigate(["/user/home"]);
          }
          else if (this.details.roles === "Admin") {
            this.router.navigate(["/admin/products"]);
          }
          else {
            this.router.navigate(["/delivery/orders"]);
          }
        })

      }
      else {
        this.ver = true;
      }
    })
  }
  SignIn() {
    this.logInService.getDeatilsWithUserName(this.email, this.roles).subscribe((data: any) => {
      console.log(data);
      if (data.length > 0 && data[0].password === this.password) {
        this.existing = false;
        localStorage.setItem("data", JSON.stringify(data));
        this.cartService.getCartData(data[0].id).subscribe((data: Cart[])=>{
          console.log(data);
          localStorage.setItem('cartLength',JSON.stringify(data.length));
        })
        this.notiService.getNotification(data[0].id).subscribe((data:Notification[])=>{
          console.log(data);
          localStorage.setItem('notiLength',JSON.stringify(data.length));
          localStorage.setItem("noti",JSON.stringify(data));
        })
        if (data[0].roles === "User") {
          this.router.navigate(["/user/home"]);
        }
        else if (data[0].roles === "Admin") {
          this.router.navigate(["/admin/products"]);
        }
        else {
          this.router.navigate(["/delivery/orders"]);
        }
      }
      else {
        this.existing = true;
      }
    });
  }
}
