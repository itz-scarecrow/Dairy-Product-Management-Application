import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CouponTableComponent } from './Admin/coupon-table/coupon-table.component';
import { DataTableComponent } from './Admin/data-table/data-table.component';
import { OrderTableComponent } from './Admin/order-table/order-table.component';
import { PaymentTableComponent } from './Admin/payment-table/payment-table.component';
import { CartComponent } from './cart/cart.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { DeliveryOrderTableComponent } from './DeliveryPartner/delivery-order-table/delivery-order-table.component';
import { EachProductComponent } from './each-product/each-product.component';
import { HomeComponent } from './home/home.component';
import { LogInComponent } from './log-in/log-in.component';
import { OfferComponentComponent } from './offer-component/offer-component.component';
import { PrevOrdersComponent } from './prev-orders/prev-orders.component';
import { ProductsComponent } from './products/products.component';

const routes: Routes = [
  { path: '', component: LogInComponent},
  { path: 'user/home', component: HomeComponent},
  { path: 'products', component: ProductsComponent },
  { path: 'product/:id', component: EachProductComponent },
  { path: 'user/cart', component: CartComponent },
  { path:'admin/products', component: DataTableComponent},
  { path:'admin/coupons',component:CouponTableComponent},
  { path:'user/product/:id', component: EachProductComponent},
  { path:'user/allProducts', component: ProductsComponent},
  { path:'user/success', component: ConfirmationComponent},
  { path:'user/orders', component:PrevOrdersComponent},
  { path:'admin/orders',component:OrderTableComponent},
  { path:'admin/payments',component:PaymentTableComponent},
  { path:'delivery/orders',component: DeliveryOrderTableComponent},
  { path:'user/offers',component: OfferComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { scrollPositionRestoration: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
