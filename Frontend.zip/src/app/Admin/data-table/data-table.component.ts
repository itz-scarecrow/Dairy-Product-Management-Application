import { Component, OnInit ,ViewChild,AfterViewInit} from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { EditDialogComponent } from '../edit-dialog/edit-dialog.component';
import { AddDialogComponent } from '../add-dialog/add-dialog.component';
import { DeleteDialogComponent } from '../delete-dialog/delete-dialog.component';
import { Product, ProductColumns } from 'src/app/Utilities/Product';
import { ProductService } from 'src/app/services/product-service.service';

@Component({
  selector: 'app-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.css']
})
export class DataTableComponent implements OnInit,AfterViewInit{

  displayedColumns: string[] = ProductColumns.map((col) => col.key);
  columnsSchema: any = ProductColumns;
  dataSource = new MatTableDataSource<Product>();
  valid: any = {};
  delete: boolean = false;
  edit: boolean = false;
  add: boolean = false;
  mulDel: boolean = false;
  idNew: number = 0;
  Selected:any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(public dialog: MatDialog, private productService: ProductService) { }

  ngOnInit() {
    this.productService.getProducts().subscribe((res: any) => {
      this.dataSource.data = res;
      console.log(this.dataSource.data);
    });
  }
  ngAfterViewInit(){
    this.dataSource.paginator=this.paginator;
    this.dataSource.sort=this.sort;
  }

  editRow(element: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = element;
    let dialogRef = this.dialog.open(EditDialogComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true
    dialogRef.afterClosed().subscribe(
      (data) => {
        console.log(data);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if(data!=undefined){
          this.productService.updateProduct(data).subscribe((data: any) => {
            console.log(data);
          });
        }
        else{
          this.productService.getProducts().subscribe((res: any) => {
            this.dataSource.data = res;
          });
        }
      });
  }

  addRow() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(AddDialogComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data.value);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data.valid === true) {
          this.productService.addProduct(data.value).subscribe((data: any) => {
            console.log(data);
            this.dataSource.data = [...this.dataSource.data, data];
            console.log(this.dataSource.data);
          });
        }
      });
  }


  removeRow(element: any) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true;
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data === true) {
          console.log(this.dataSource.data);
          this.dataSource.data = this.dataSource.data.filter(function (item) {
            return item.id !== element.id;
          });
          console.log(this.dataSource.data);
          this.productService.deleteProduct(element.id).subscribe((data: any) => {
            console.log("Succesfully Deleted");
          });
        }
      });

  }

  removeSelectedRows() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(DeleteDialogComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true;
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data === true) {
          console.log(this.dataSource.data);
          this.Selected=this.dataSource.data.filter(function (item) {
            return item.isSelected;
          });
          this.dataSource.data = this.dataSource.data.filter(function (item) {
            return !item.isSelected;
          });
          console.log(this.Selected);
          this.productService.deleteMultipleProducts(this.Selected).subscribe((data)=>{
            console.log("Multiple Delete Successful");
          });
        }
      });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  min(a:number,b:number){
    return Math.min(a,b);
  }

}
