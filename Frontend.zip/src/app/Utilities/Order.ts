import { Cart } from "./Cart";

export class Order{
    id:string="";
    orderId:string="";
    userid:string="";
    username:string="";
    orders:Cart[]=[];
    totalprice:number=0;
    paymentStatus:string="";
    orderStatus: string="";
    date:string="";
    dispatchdate:string="";
    deliverydate:string="";
    delivery:number=0;
    discount:number=0;
}