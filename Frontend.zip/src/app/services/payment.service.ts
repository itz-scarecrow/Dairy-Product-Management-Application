import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Payment } from '../Utilities/Payment';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {
  url:string='http://localhost:4400/api';
  constructor(private http: HttpClient) { }
  makePayment(sum: number):Observable<any> {
    return this.http.post<any>(`${this.url}/createOrder`,{amount: sum});
  }
  getPayment():Observable<any>{
    return this.http.get<any>(`${this.url}/payment/get`);
  }
  postPayment(body: Payment):Observable<Payment>{
    return this.http.post<Payment>(`${this.url}/payment/add`,body);
  }
}
