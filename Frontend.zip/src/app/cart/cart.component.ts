import { Component, ElementRef, HostListener, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CartserviceService } from '../services/cartservice.service';
import { Cart } from '../Utilities/Cart';
import { MatSnackBar } from '@angular/material/snack-bar';
import { PaymentService } from '../services/payment.service';
import { LogIn } from '../Utilities/LogIn';
import { LoginServiceService } from '../services/login-service.service';
import { ColdObservable } from 'rxjs/internal/testing/ColdObservable';
import { CouponserviceService } from '../services/couponservice.service';
import { CouponData } from '../Utilities/CouponData';
import { Order } from '../Utilities/Order';
import { OrdersService } from '../services/orders.service';
import { Payment } from '../Utilities/Payment';
declare var Razorpay: any;
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartData: Cart[] = [];
  impdata: any;
  userid: string = "";
  prefix: string = "../../assets/images/";
  totalPrice: number = 0;
  userData: any;
  valid1: boolean = true;
  valid2: boolean = true;
  couponCode: string = "";
  discount: number = 0;
  deliveryDetails: String = "instant";
  deliveryPrice: number = 0;
  cartDataCopy: any;
  passData: any;
  orderData: Order = {
    id: '',
    userid: '',
    username: '',
    orders: [],
    totalprice: 0,
    paymentStatus: '',
    orderStatus: '',
    orderId: '',
    date: '',
    delivery: 0,
    discount: 0,
    dispatchdate: '',
    deliverydate: ''
  };
  paymentData: Payment = {
    id: '',
    userid: '',
    paymentid: '',
    username: '',
    paymentmode: '',
    paymentstatus: '',
    totalPrice: 0
  }
  constructor(private service: CartserviceService, private router: Router, private snackBar: MatSnackBar, private pay: PaymentService, private login: LoginServiceService, private coupon: CouponserviceService, private orderService: OrdersService) {
    // this.impdata=this.router.getCurrentNavigation()?.extras.state;
    // this.userid=this.impdata.data;
    // console.log(this.userid);
  }

  ngOnInit(): void {
    this.userid = JSON.parse(localStorage.getItem('data') || '{}')[0].id;
    console.log(this.userid);
    this.login.getDetailsWithId(this.userid).subscribe((data: any) => {
      console.log(data);
      this.userData = data;
    });
    this.service.getCartData(this.userid).subscribe((data: Cart[]) => {
      this.cartData = data;
      this.service.showCartData(data);
      if (data.length == 0) {
        this.valid1 = false;
      }
      else {
        this.valid1 = true;
      }
    })
  }
  add(item: Cart) {
    item.quantity++;
    this.service.changeQuantity(item.id, item.quantity).subscribe((data: Cart) => {
      console.log(data);
    })
  }
  sub(item: Cart) {
    if (item.quantity - 1 <= 0) {
      this.snackBar.open("Can't Make Quantity To Zero!", "", {
        duration: 1500,
        panelClass: ['red-snackbar']
      });
    }
    else {
      item.quantity--;
      this.service.changeQuantity(item.id, item.quantity).subscribe((data: Cart) => {
        console.log(data);
      })
    }
  }
  delete(item: Cart) {
    this.cartData = this.cartData.filter((eachData) => {
      return eachData.id !== item.id
    })
    console.log(this.cartData);
    localStorage.setItem('cartLength', JSON.stringify(this.cartData.length));
    this.service.deleteCartData(item.id).subscribe(() => {
      console.log("Successfully Deleted");
      this.service.showCartData(this.cartData);

    });
  }
  codeVal(e: Event) {
    this.couponCode = (e.target as HTMLInputElement).value.toUpperCase();
    if (this.couponCode !== '') {
      this.coupon.getCouponByName(this.couponCode).subscribe((data: CouponData[]) => {
        if (data.length === 1) {
          this.discount = data[0].discount;
          this.valid2 = true;
        }
        else {
          this.discount = 0;
          this.valid2 = false;
        }
      })
    }
    else {
      this.discount = 0;
      this.valid2 = true;
    }
  }
  calcSumOfData() {
    this.totalPrice = 0;
    for (let i = 0; i < this.cartData.length; i++) {
      this.totalPrice += this.cartData[i].price * this.cartData[i].quantity;
    }
    return this.totalPrice;
  }
  calcSum() {
    if (this.deliveryDetails === 'instant') {
      this.deliveryPrice = 100;
      return (this.totalPrice + 100) - ((this.totalPrice + 100) * this.discount) / 100;
    }
    else if (this.deliveryDetails === 'late-3') {
      this.deliveryPrice = 50;
      return (this.totalPrice + 50) - ((this.totalPrice + 50) * this.discount) / 100;
    }
    else if (this.deliveryDetails === 'late-5') {
      this.deliveryPrice = 30;
      return (this.totalPrice + 30) - ((this.totalPrice + 30) * this.discount) / 100;
    }
    else {
      this.deliveryPrice = 0;
      return this.totalPrice - (this.totalPrice * this.discount) / 100;
    }
  }
  options = {
    "key": "",
    "amount": "",
    "name": "",
    "order_id": "",
    "handler": function (response: any) {
      var event = new CustomEvent("payment.success",
        {
          detail: response,
          bubbles: true,
          cancelable: true
        }
      );
      window.dispatchEvent(event);
    }
    ,
    "prefill": {
      "name": "",
      "email": "",
      "contact": ""
    },
    "notes": {
      "address": ""
    },
    "theme": {
      "color": "#3399cc"
    }
  };
  paymentId: string = "";
  error: string = "";
  payment(price: number): void {
    this.paymentId = '';
    this.error = '';
    this.pay.makePayment(this.calcSum()).subscribe(
      (data) => {
        console.log(data);
        this.options.key = data.secretId;
        this.options.order_id = data.razorpayOrderId;
        this.options.amount = data.applicationFee;
        this.options.prefill.name = this.userData.username;
        this.options.prefill.email = this.userData.email;
        this.options.prefill.contact = "";
        var rzp1 = new Razorpay(this.options);
        rzp1.open();
        rzp1.on('payment.failed', (response: any) => {
          console.log(response);
          console.log(response.error.code);
          console.log(response.error.description);
          console.log(response.error.source);
          console.log(response.error.step);
          console.log(response.error.reason);
          console.log(response.error.metadata.order_id);
          console.log(response.error.metadata.payment_id);
          this.error = response.error.reason;
        }
        );
      }
      ,
      err => {
        this.error = err.error.message;
      }
    );
  }

  @HostListener('window:payment.success', ['$event'])
  onPaymentSuccess(event: any): void {
    console.log(event);
    console.log(event.detail);
    let d = new Date();
    this.orderData.date = d.getDate() + "/" + d.getMonth() + "/" + d.getFullYear();
    this.orderData.orderId = event.detail.razorpay_order_id;
    this.orderData.userid = this.userid;
    this.orderData.username = this.userData.username;
    this.orderData.orders = this.cartData;
    this.orderData.totalprice = this.calcSum();
    this.orderData.delivery = this.deliveryPrice;
    this.orderData.discount = (this.deliveryPrice + this.calcSumOfData()) * this.discount / 100;
    this.orderData.paymentStatus = "Paid";
    this.orderData.orderStatus = "Ordered";
    console.log(this.orderData);
    this.service.deleteMultipleCartItems(this.cartData).subscribe(() => {
      console.log("successfully deleted cart items");
    });
    this.cartDataCopy = this.cartData;
    let sum = 0;
    for (let i = 0; i < this.cartDataCopy.length; i++) {
      sum += this.cartData[i].price * this.cartData[i].quantity;
    }
    this.orderService.addOrders(this.orderData).subscribe((data: Order) => {
      console.log(data);
    });
    this.paymentData.userid = this.userid;
    this.paymentData.paymentid = event.detail.razorpay_payment_id;
    this.paymentData.paymentmode = "Online";
    this.paymentData.paymentstatus = "Paid";
    this.paymentData.totalPrice = this.calcSum();
    this.paymentData.username = this.userData.username;
    console.log(this.paymentData);
    this.pay.postPayment(this.paymentData).subscribe((data) => {
      console.log(data);
    })
    this.cartData = [];
    localStorage.setItem('cartLength', JSON.stringify(this.cartData.length));
    this.passData = {
      orderId: event.detail.razorpay_order_id,
      item: this.cartDataCopy.length,
      price: sum,
      totalPrice: this.calcSum(),
      deliveryPrice: this.deliveryPrice,
      discount: this.discount,
      userId: this.userid
    }
    localStorage.setItem('passingData',JSON.stringify(this.passData));
    this.router.navigate(["/user/success"]);

  }

}
