import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { forkJoin, Observable } from 'rxjs';
import { Notification } from '../Utilities/Notification';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {
  url:string="http://localhost:4400/api";
  constructor(private http:HttpClient) { }
  postNotification(body:Notification):Observable<Notification>{
    return this.http.post<Notification>(`${this.url}/notification/add`,body);
  }
  getNotification(userid:String):Observable<Notification[]>{
    return this.http.get<Notification[]>(`${this.url}/notification/get/${userid}`);
  }
  deleteNotification(datas:Notification[]):Observable<any>{
    console.log(datas);
    return forkJoin(
      datas.map((data: any) =>
        this.http.delete<any>(`${this.url}/notification/delete/${data.id}`)
      ));
  }
}
