export class Notification{
    id: string="";
    userid:string="";
    orderid:string="";
    description:string=""; 
    date:string="";
}