import { Component, OnInit, AfterViewInit, DoCheck } from '@angular/core';
import { Router } from '@angular/router';
import { CartserviceService } from '../services/cartservice.service';
import { LoginServiceService } from '../services/login-service.service';
import { NotificationService } from '../services/notification.service';
import { Cart } from '../Utilities/Cart';
import { LogIn } from '../Utilities/LogIn';
import { Notification } from '../Utilities/Notification';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit, AfterViewInit, DoCheck {
  isLoggedIn: boolean = false;
  user: String = "John Doe";
  userRole: String = "Role";
  role: String = "Role";
  userdata: any;
  cart: Cart[]=[];
  adminNav:string="products";
  deliveryNav: string="orders"
  cartLength: number=0;
  notiLength: number=0;
  notiData:Notification[]=[];
  constructor(private service: LoginServiceService,private cartservice: CartserviceService,private notiService:NotificationService,private router:Router) {

  }

  ngOnInit(): void {

  }
  ngAfterViewInit(): void {

  }
  ngDoCheck(): void {
    this.userdata=JSON.parse(localStorage.getItem('data') || '{}');
    if(this.userdata.length>0){
      this.isLoggedIn=true;
      this.role=this.userdata[0].roles;
      this.user=this.userdata[0].username;
    }
  }
  calc(): number{
    this.cartLength=JSON.parse(localStorage.getItem('cartLength')||'{}');
    return this.cartLength;
  }
  calcNoti():number{
    this.notiLength=JSON.parse(localStorage.getItem('notiLength')||'{}');
    this.notiData=JSON.parse(localStorage.getItem('noti')||'{}');
    return this.notiLength;
  }
  update(){
    this.isLoggedIn=false;
    this.adminNav="products";
    this.deliveryNav="orders";
    this.user="John Doe";
    this.role= "Role";
    localStorage.clear();
    this.router.navigate(['/'])
  }
  delete(){
    this.notiService.deleteNotification(this.notiData).subscribe(()=>{
      console.log("succesfully deleted notifications");
      this.notiData=[];
      this.notiLength=0;
      localStorage.setItem('noti',JSON.stringify(this.notiData));
      localStorage.setItem("notiLength",JSON.stringify(this.notiLength));
      this.calcNoti();
    })
  }
}
