import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NotificationService } from 'src/app/services/notification.service';
import { OrdersService } from 'src/app/services/orders.service';
import { Notification } from 'src/app/Utilities/Notification';
import { Order } from 'src/app/Utilities/Order';
import { OrderColumns, OrderData } from 'src/app/Utilities/OrderData';

@Component({
  selector: 'app-order-table',
  templateUrl: './order-table.component.html',
  styleUrls: ['./order-table.component.css']
})
export class OrderTableComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = OrderColumns.map((col) => col.key);
  columnsSchema: any = OrderColumns;
  dataSource = new MatTableDataSource<OrderData>();
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  notiData: Notification = {
    id: '',
    userid: '',
    orderid: '',
    description: '',
    date: ''
  };
  notifyData: any;
  constructor(private service: OrdersService, private notify: NotificationService) { }

  ngOnInit(): void {
    this.service.getAllOrders().subscribe((data: any) => {
      console.log(data);
      this.dataSource.data = data;
    })
  }
  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  dispatch(element: any) {
    element.orderStatus = "Dispatched";
    let d = new Date();
    element.dispatchdate = d.getDate() + "/" + d.getMonth() + "/" + d.getFullYear();
    this.service.updateStatus(element).subscribe((data) => {
      console.log(data);
      this.notifyData = JSON.parse(localStorage.getItem('noti') || '[]');
      this.notiData.userid = data.userid;
      this.notiData.orderid = data.orderId;
      this.notiData.description = "We have successfully dispatch your order!!";
      this.notiData.date = data.dispatchdate;
      console.log(this.notiData);
      this.notify.postNotification(this.notiData).subscribe((data: any) => {
        console.log(data);
        this.notiData.id=data.id;
        this.notifyData.push(this.notiData);
        localStorage.setItem('noti', JSON.stringify(this.notifyData));
        localStorage.setItem('notiLength', JSON.stringify(this.notifyData.length));
      })
    })
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


}
