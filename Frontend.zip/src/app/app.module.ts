import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MatIconModule } from '@angular/material/icon';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { LogInComponent } from './log-in/log-in.component';
import { HomeComponent } from './home/home.component';
import { ProductsComponent } from './products/products.component';
import { EachProductComponent } from './each-product/each-product.component';
import { CartComponent } from './cart/cart.component';
import { ReactiveFormsModule } from '@angular/forms';
import { CdkTableModule } from '@angular/cdk/table';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatMenuModule } from '@angular/material/menu';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { HttpClientModule } from '@angular/common/http';
import { DataTableComponent } from './Admin/data-table/data-table.component';
import { DeleteDialogComponent } from './Admin/delete-dialog/delete-dialog.component';
import { AddDialogComponent } from './Admin/add-dialog/add-dialog.component';
import { EditDialogComponent } from './Admin/edit-dialog/edit-dialog.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CartConfirmationComponent } from './cart-confirmation/cart-confirmation.component';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatCardModule} from '@angular/material/card';
import { CouponTableComponent } from './Admin/coupon-table/coupon-table.component';
import { AddCouponComponent } from './Admin/add-coupon/add-coupon.component';
import { EditCouponComponent } from './Admin/edit-coupon/edit-coupon.component';
import { DeleteCouponComponent } from './Admin/delete-coupon/delete-coupon.component';
import { ConfirmationComponent } from './confirmation/confirmation.component';
import { PrevOrdersComponent } from './prev-orders/prev-orders.component';
import { OrderTableComponent } from './Admin/order-table/order-table.component';
import { PaymentTableComponent } from './Admin/payment-table/payment-table.component';
import { DeliveryOrderTableComponent } from './DeliveryPartner/delivery-order-table/delivery-order-table.component';
import { OfferComponentComponent } from './offer-component/offer-component.component';
import { ProfileComponent } from './profile/profile.component';
@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    LogInComponent,
    HomeComponent,
    ProductsComponent,
    EachProductComponent,
    CartComponent,
    DataTableComponent,
    DeleteDialogComponent,
    AddDialogComponent,
    EditDialogComponent,
    CartConfirmationComponent,
    CouponTableComponent,
    AddCouponComponent,
    EditCouponComponent,
    DeleteCouponComponent,
    ConfirmationComponent,
    PrevOrdersComponent,
    OrderTableComponent,
    PaymentTableComponent,
    DeliveryOrderTableComponent,
    OfferComponentComponent,
    ProfileComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    CdkTableModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatMenuModule,
    MatIconModule,
    MatButtonModule,
    MatDialogModule,
    ReactiveFormsModule,
    MatInputModule,
    MatSelectModule,
    FormsModule,
    MatToolbarModule,
    HttpClientModule,
    MatCheckboxModule,
    MatSnackBarModule,
    MatCardModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
