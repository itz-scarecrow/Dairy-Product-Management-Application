export interface Product{
    isSelected: boolean;
    id: string;
    imageValue: string;
    imageUrl: string;
    productName: string;
    brandName: string;
    price: number;
    saleStatus: string;
    saleValue: number;
    discountedPrice: number;
    productStatus: string;
    rating:string;
    category: string;
    description: string;
    isEdit: boolean;
  }
  
  export const ProductColumns = [
    {
      key: 'isSelected',
      type: 'isSelected',
      label: 'Select',
    },
    {
      key:'imageUrl',
      type: 'text',
      label: 'Image',
      required: true,
    },
    {
      key: 'productName',
      type: 'text',
      label: 'Product',
      required: true,
    },
    {
      key: 'brandName',
      type: 'text',
      label: 'Brand',
    },
    {
      key:'price',
      type:'number',
      label:'Marked Price (Rs.)',
      required: true,

    },
    {
      key: 'saleStatus',
      type: 'string',
      label: 'Sale Status',
      required: true,
    },
    {
      key: 'saleValue',
      type: 'Number',
      label: 'Sale (%)',
      required: true
    },
    {
      key: 'discountedPrice',
      type: 'Number',
      label: 'Discounted Price (Rs.)',
      required: true
    },
    {
      key: 'productStatus',
      type: 'text',
      label: 'Product Status',
      required: true
    },
    {
      key:'rating',
      type:'text',
      label:'Rating',
      required: true
    },
    {
      key:'category',
      type:'text',
      label:'Category',
      required: true
    },
    {
      key:'description',
      type:'text',
      label:'Description',
      required: true
    },
    {
      key: 'isEdit',
      type: 'isEdit',
      label: '',
    },
  ];