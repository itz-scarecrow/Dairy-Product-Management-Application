import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartserviceService } from '../services/cartservice.service';
import { OrdersService } from '../services/orders.service';
import { Cart } from '../Utilities/Cart';
import { Order } from '../Utilities/Order';

@Component({
  selector: 'app-prev-orders',
  templateUrl: './prev-orders.component.html',
  styleUrls: ['./prev-orders.component.css']
})
export class PrevOrdersComponent implements OnInit {
  data:any;
  userid:string="";
  orderData:any;
  prefix:string="../../assets/images/";
  constructor(private router:Router,private service:OrdersService,private cartService:CartserviceService) { 
    // this.data=this.router.getCurrentNavigation()?.extras.state;
    // this.userid=this.data.data;
    // console.log(this.userid);
  }

  ngOnInit(): void {
    this.data=JSON.parse(localStorage.getItem('data')|| '{}');
    this.userid=this.data[0].id;
    console.log(this.userid);
    this.service.getOrdersOfUser(this.userid).subscribe((data:any)=>{
      this.orderData=data;
      console.log(this.orderData);
      this.orderData.reverse();
    })
  }
  repeat(data: Cart[]){
    for(let i=0;i<data.length;i++){
      data[i].id="";
    }
    this.cartService.addMultipleInCart(data).subscribe((data:any)=>{
      console.log(data);
      this.cartService.showCartData(data);
      console.log(this.orderData.userid);
      this.router.navigate(['/user/cart'],{state:{data:this.userid}});
    })
  }
  del(id:string){
    this.orderData=this.orderData.filter((item:any)=> {
      return item.id !== id;
    });
    this.service.deleteOrder(id).subscribe(()=>{
      console.log("Order Deleted");
    })
  }

}
