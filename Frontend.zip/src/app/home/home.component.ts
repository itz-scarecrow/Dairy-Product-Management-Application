import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../services/product-service.service';
import { ProductData } from '../Utilities/ProducData';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit{
  dataid:any;
  id: string="";
  window: number=0;
  getData: any=[];
  prefix:string="../../assets/images/";
  count:any=[];
  constructor(private router: Router,private productService: ProductService) { 
    // this.dataid=this.router.getCurrentNavigation()?.extras.state;
    // this.id=this.dataid.data;
  }
  ngOnInit(): void {
    this.dataid=JSON.parse(localStorage.getItem('data')|| '{}');
    this.id=this.dataid[0].id;
    console.log(this.id);
    this.productService.getLastestProducts().subscribe((data: any)=>{
      this.getData=data;
      console.log(this.getData);
      this.window=this.getData.length/3;
      console.log(this.window)
      for(let i=1;i<this.window;i++){
        this.count.push(i);
      }
      console.log(this.getData);
    })
  }

}
