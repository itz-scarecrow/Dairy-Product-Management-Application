import { Component, ElementRef, OnInit, ViewChild,OnDestroy,AfterViewInit} from '@angular/core';
import { Router } from '@angular/router';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { NotificationService } from '../services/notification.service';
import { Notification } from '../Utilities/Notification';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css']
})
export class ConfirmationComponent implements OnInit,AfterViewInit {
  data:any;
  tempdata:any
  notiData: Notification={
    id: '',
    userid: '',
    orderid: '',
    description: '',
    date: ''
  }
  notifyData:any;
  @ViewChild("convert") ele!: ElementRef;
  constructor(private router: Router,private service: NotificationService) { 

  }
  ngOnInit(): void {
    this.tempdata=JSON.parse(localStorage.getItem('passingData')|| '{}');
    this.data=this.tempdata;
    console.log(this.data);
    this.notifyData=JSON.parse(localStorage.getItem('noti')||'[]');
    this.notiData.userid=this.data.userId;
    this.notiData.orderid=this.data.orderId;
    this.notiData.description="Your order has been successfully received!!";
    let d = new Date();
    this.notiData.date=d.getDate() + "/" + d.getMonth() + "/" + d.getFullYear();
    this.service.postNotification(this.notiData).subscribe((data:Notification)=>{
      console.log(data);
      this.notiData.id=data.id;
      this.notifyData.push(this.notiData);
      localStorage.setItem('noti',JSON.stringify(this.notifyData));
      localStorage.setItem('notiLength',JSON.stringify(this.notifyData.length));
    })
  }
  ngAfterViewInit(): void {
    console.log(this.ele);
  }
  delete(){
    localStorage.removeItem('passingData');
  }
  generatePdf(){
    html2canvas(this.ele.nativeElement).then((canvas)=>{
      const imgData=canvas.toDataURL('image/jpeg')
      const pdf= new jsPDF({
        orientation:'portrait'
      })
      const imageProps=pdf.getImageProperties(imgData);
      const pdfw=pdf.internal.pageSize.getWidth();
      const pdfh=(imageProps.height*pdfw)/imageProps.width;
      pdf.addImage(imgData,'PNG',0,0,pdfw,pdfh);
      pdf.save("receipt.pdf");
    })
  }

}
