import { Component, OnInit, ViewChild,AfterViewInit} from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { CouponserviceService } from 'src/app/services/couponservice.service';
import { Coupon, CouponColumns } from 'src/app/Utilities/Coupon';
import { CouponData } from 'src/app/Utilities/CouponData';
import { AddCouponComponent } from '../add-coupon/add-coupon.component';
import { DeleteCouponComponent } from '../delete-coupon/delete-coupon.component';
import { EditCouponComponent } from '../edit-coupon/edit-coupon.component';

@Component({
  selector: 'app-coupon-table',
  templateUrl: './coupon-table.component.html',
  styleUrls: ['./coupon-table.component.css']
})
export class CouponTableComponent implements OnInit,AfterViewInit {
  displayedColumns: string[] = CouponColumns.map((col) => col.key);
  columnsSchema: any = CouponColumns;
  dataSource = new MatTableDataSource<Coupon>();
  delete: boolean = false;
  edit: boolean = false;
  add: boolean = false;
  mulDel: boolean = false;
  Selected: any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(private dialog: MatDialog,private service:CouponserviceService) {

  }

  ngOnInit(): void {
    this.service.getAllCoupon().subscribe((data:any)=>{
      console.log(data);
      this.dataSource.data=data;
    });
  }
  ngAfterViewInit(): void {
    this.dataSource.paginator=this.paginator;
    this.dataSource.sort=this.sort;
  }
  addRow() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(AddCouponComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data.value);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data.valid === true) {
          this.service.addNewCoupon(data.value).subscribe((data: any) => {
            console.log(data);
            this.dataSource.data = [...this.dataSource.data, data];
            console.log(this.dataSource.data);
          });
        }
      });
  }
  removeSelectedRows(){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(DeleteCouponComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true;
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data === true) {
          console.log(this.dataSource.data);
          this.Selected=this.dataSource.data.filter(function (item) {
            return item.isSelected;
          });
          this.dataSource.data = this.dataSource.data.filter(function (item) {
            return !item.isSelected;
          });
          console.log(this.Selected);
          this.service.deleteMultipleCoupons(this.Selected).subscribe(()=>{
            console.log("Multiple Delete Successful");
          });
        }
      });
  }
  editRow(element: any){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    dialogConfig.data = element;
    let dialogRef = this.dialog.open(EditCouponComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true
    dialogRef.afterClosed().subscribe(
      (data) => {
        console.log(data);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if(data!=undefined){
          this.service.editCoupon(data).subscribe((data: any) => {
            console.log(data);
          });
        }
        else{
          this.service.getAllCoupon().subscribe((res: any) => {
            this.dataSource.data = res;
          });
        }
      });
  }
  removeRow(element:any){
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;
    let dialogRef = this.dialog.open(DeleteCouponComponent, dialogConfig);
    this.edit = true;
    this.delete = true;
    this.add = true;
    this.mulDel = true;
    dialogRef.afterClosed().subscribe(
      data => {
        console.log(data);
        this.edit = false;
        this.delete = false;
        this.add = false;
        this.mulDel = false;
        if (data === true) {
          console.log(this.dataSource.data);
          this.dataSource.data = this.dataSource.data.filter(function (item) {
            return item.id !== element.id;
          });
          console.log(this.dataSource.data);
          this.service.deleteCoupon(element.id).subscribe((data: any) => {
            console.log("Succesfully Deleted");
          });
        }
      });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
