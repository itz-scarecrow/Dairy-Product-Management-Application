
export interface PaymentData{
    id: string;
    paymentid:string;
    username: string;
    totalPrice: number;
    paymentmode: string;
    paymentstatus: string;
  }
  
  export const PaymentColumns = [
    {
      key:'paymentid',
      type: 'text',
      label: 'Payment Id',
      required: true,
    },
    {
      key: 'username',
      type: 'text',
      label: 'Customer Name',
      required: true,
    },
    {
      key: 'totalPrice',
      type: 'number',
      label: 'Total Paid( Rs.)',
    },
    {
      key: 'paymentmode',
      type: 'string',
      label: 'Payment Mode',
    },
    {
        key: 'paymentstatus',
        type: 'text',
        label: 'Payment Status',
        required: true
    }
  ];