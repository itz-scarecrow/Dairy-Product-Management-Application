import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product-service.service';
import { ProductData } from '../Utilities/ProducData';

@Component({
  selector: 'app-offer-component',
  templateUrl: './offer-component.component.html',
  styleUrls: ['./offer-component.component.css']
})
export class OfferComponentComponent implements OnInit {
  prodData: ProductData[]=[];
  prefix:string="../../assets/images/";
  constructor(private service: ProductService) { }

  ngOnInit(): void {
    this.service.findsaleProducts("On Sale").subscribe((data)=>{
      console.log(data);
      this.prodData=data;
    })
  }

}
