import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NotificationService } from 'src/app/services/notification.service';
import { OrdersService } from 'src/app/services/orders.service';
import { Notification } from 'src/app/Utilities/Notification';
import { OrderColumns, OrderData } from 'src/app/Utilities/OrderData';
import { isThrowStatement } from 'typescript';

@Component({
  selector: 'app-delivery-order-table',
  templateUrl: './delivery-order-table.component.html',
  styleUrls: ['./delivery-order-table.component.css']
})
export class DeliveryOrderTableComponent implements OnInit, AfterViewInit {
  displayedColumns: string[] = OrderColumns.map((col) => col.key);
  columnsSchema: any = OrderColumns;
  dataSource = new MatTableDataSource<OrderData>();
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  notiData: Notification = {
    id: '',
    userid: '',
    orderid: '',
    description: '',
    date: ''
  }
  notifyData: any;
  constructor(private service: OrdersService, private notify: NotificationService) { }

  ngOnInit(): void {
    this.service.getAllOrders().subscribe((data: any) => {
      console.log(data);
      this.dataSource.data = data;
      this.dataSource.data = this.dataSource.data.filter((item) => {
        return item.orderStatus !== 'Ordered'
      })
    })
  }
  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  deliver(element: any) {
    element.orderStatus = "Delivered";
    let d = new Date();
    element.deliverydate = d.getDate() + "/" + d.getMonth() + "/" + d.getFullYear();
    this.service.updateStatus(element).subscribe((data) => {
      console.log(data);
    })
    this.notifyData = JSON.parse(localStorage.getItem('noti') || '[]');
    this.notiData.userid = element.userid;
    this.notiData.orderid = element.orderId;
    this.notiData.description = "Your order has been successfully delivered😀😀";
    this.notiData.date = element.deliverydate;
    console.log(this.notiData);
    this.notify.postNotification(this.notiData).subscribe((data: any) => {
      console.log(data);
      this.notifyData.id=data.id;
      this.notifyData.push(this.notiData);
      localStorage.setItem('noti', JSON.stringify(this.notifyData));
      localStorage.setItem('notiLength', JSON.stringify(this.notifyData.length));
    })
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


}

