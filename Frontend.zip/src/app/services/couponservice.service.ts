import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { forkJoin, Observable } from 'rxjs';
import { CouponData } from '../Utilities/CouponData';

@Injectable({
  providedIn: 'root'
})
export class CouponserviceService {
  url:string="http://localhost:4400/api";
  constructor(private http: HttpClient) { }
  addNewCoupon(data: CouponData):Observable<CouponData>{
    return this.http.post<CouponData>(`${this.url}/coupon/add`,data);
  }
  getCouponByName(code: string):Observable<CouponData[]>{
    return this.http.get<CouponData[]>(`${this.url}/coupon/${code}`);
  }
  getAllCoupon():Observable<CouponData[]>{
    return this.http.get<CouponData[]>(`${this.url}/coupon/get`);
  }
  editCoupon(data:any):Observable<CouponData>{
    return this.http.put<CouponData>(`${this.url}/coupon/edit/${data.id}`,data);
  }
  deleteCoupon(id: string){
    return this.http.delete<CouponData>(`${this.url}/coupon/delete/${id}`);
  }
  deleteMultipleCoupons(datas: CouponData[]): Observable<any> {
    return forkJoin(
      datas.map((data: any) =>
        this.http.delete<any>(`${this.url}/coupon/delete/${data.id}`)
      ));
  }
}
