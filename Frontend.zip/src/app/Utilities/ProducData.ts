export interface ProductData {
  id: string;
  imageValue: string;
  imageUrl: string;
  productName: string;
  brandName: string;
  price: number;
  saleStatus: string;
  saleValue: number;
  discountedPrice: number;
  rating:string,
  productStatus: string;
  description: string;
  category: string;
}