export interface CouponData{
    id: string;
    code: string;
    discount:number;

}