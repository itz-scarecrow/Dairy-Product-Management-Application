import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Order } from '../Utilities/Order';

@Injectable({
  providedIn: 'root'
})
export class OrdersService {
  url:string="http://localhost:4400/api";
  constructor(private http: HttpClient) { }
  addOrders(data:any):Observable<any>{
    console.log(data);
    return this.http.post<any>(`${this.url}/orders/post`,data);
  }
  getOrdersOfUser(userid:string):Observable<Order[]>{
    return this.http.get<Order[]>(`${this.url}/orders/get/${userid}`);
  }
  deleteOrder(id:string):Observable<any>{
    return this.http.delete<any>(`${this.url}/orders/delete/${id}`)
  }
  getAllOrders():Observable<Order[]>{
    return this.http.get<Order[]>(`${this.url}/orders/getAll`);
  }
  updateStatus(data:any):Observable<Order>{

    return this.http.put<Order>(`${this.url}/orders/updateOrderStatus/${data.id}`,data);
  }
  getDataByStatus(Status: string):Observable<Order[]>{
    return this.http.get<Order[]>(`${this.url}/orders/getData/${Status}`);
  }
}
