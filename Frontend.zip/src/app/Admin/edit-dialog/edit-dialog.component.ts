import { Component, Inject, OnInit,DoCheck} from '@angular/core';
import { MAT_DIALOG_DATA,MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-edit-dialog',
  templateUrl: './edit-dialog.component.html',
  styleUrls: ['./edit-dialog.component.css']
})
export class EditDialogComponent implements OnInit,DoCheck {
  rowData: any;
  obj: any;
  gender: any= [
    { value: 'Male', viewValue: 'Male' },
    { value: 'Female', viewValue: 'Female' }
  ];
  constructor(@Inject(MAT_DIALOG_DATA) private data: any,private dialogRef: MatDialogRef<EditDialogComponent>) { 
    this.rowData=data;
  }

  ngOnInit(): void {
  }
  ngDoCheck(): void {
    if(this.rowData.saleStatus==='Not On Sale'){
      this.rowData.saleValue=0;
      this.rowData.discountedPrice=this.rowData.price;
    }
    else{
      this.rowData.discountedPrice=this.rowData.price-((this.rowData.price*this.rowData.saleValue)/100);
    }
}
store(e: Event){
  this.obj= (e.target as HTMLInputElement).files;
  this.rowData.imageValue=(e.target as HTMLInputElement).value
  this.rowData.imageUrl=this.obj[0].name;
}
  cancelChange(){
    this.dialogRef.close();
  }
  doneChange(){
    this.dialogRef.close(this.rowData);
  }

  

}
