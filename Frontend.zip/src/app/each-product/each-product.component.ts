import { Component, OnInit,OnDestroy} from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { matSelectAnimations } from '@angular/material/select';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router,ActivatedRoute } from '@angular/router';
import { CartConfirmationComponent } from '../cart-confirmation/cart-confirmation.component';
import { CartserviceService } from '../services/cartservice.service';
import { ProductService } from '../services/product-service.service';
import { Cart } from '../Utilities/Cart';
import { ProductData } from '../Utilities/ProducData';
import {MatCardModule} from '@angular/material/card';

@Component({
  selector: 'app-each-product',
  templateUrl: './each-product.component.html',
  styleUrls: ['./each-product.component.css']
})
export class EachProductComponent implements OnInit,OnDestroy {
  data:any;
  userid: string="";
  prodid: any;
  sub: any;
  prodData: ProductData={
    id: '',
    imageValue: '',
    imageUrl: '',
    productName: '',
    brandName: '',
    price: 0,
    saleStatus: '',
    saleValue: 0,
    discountedPrice: 0,
    rating: '',
    productStatus: '',
    description: '',
    category: ''
  };
  quantity: number=1;
  prefix:string="../../assets/images/";
  cartData: Cart={
    id: '',
    userId: '',
    imageUrl: '',
    quantity: 0,
    price: 0,
    category: '',
    brandName: '',
    productname: ''
  };
  constructor(private router: Router,private activatedroute:ActivatedRoute,private service: ProductService,private cart:CartserviceService,private snackBar: MatSnackBar) {
  }

  ngOnInit(): void {
    this.data=JSON.parse(localStorage.getItem('data')|| '{}');
    this.userid=this.data[0].id;
    console.log(this.userid);
    this.sub=this.activatedroute.paramMap.subscribe(params => { 
      this.prodid = params.get('id');
      console.log(this.prodid);
    });
    this.service.findProductById(this.prodid).subscribe((data: ProductData)=>{
      this.prodData=data;
      console.log(this.prodData);
    })
  }
  addQuantity(e:Event){
    this.quantity=parseInt((e.target as HTMLInputElement).value);
    console.log(this.quantity);
  }
  addInCart(){
    this.cartData.userId=this.userid;
    this.cartData.imageUrl=this.prodData.imageUrl;
    this.cartData.quantity=this.quantity;
    this.cartData.category=this.prodData.category;
    this.cartData.brandName=this.prodData.brandName;
    this.cartData.productname=this.prodData.productName;
    this.cartData.price=this.prodData.discountedPrice;
    console.log(this.cartData);
    this.cart.addInCart(this.cartData).subscribe((data:Cart[])=>{
      console.log(data);
      this.cart.getCartData(this.userid).subscribe((data: Cart[])=>{
        console.log(data);
        localStorage.setItem('cartLength',JSON.stringify(data.length));
      });
    })
    this.snackBar.open("Successfully Added To Cart!", "",{
      duration: 1500,
      panelClass: ['blue-snackbar']
    });
  }
  ngOnDestroy(): void {
      console.log("in destroy");
  }
  
}
