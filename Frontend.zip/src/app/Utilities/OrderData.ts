import { Cart } from "./Cart";

export interface OrderData{
    id: string;
    orderId: string;
    userid: string;
    username: string;
    orders: Cart[];
    totalprice: number;
    paymentStatus: string;
    orderStatus: string;
    date: string;
    dispatchdate: string;
    deliverydate: string;
    delivery: number;
    discount: number;
    isUpdated: boolean;
  }
  
  export const OrderColumns = [
    {
      key:'orderId',
      type: 'text',
      label: 'Order Id',
      required: true,
    },
    {
      key: 'username',
      type: 'text',
      label: 'Customer Name',
      required: true,
    },
    {
      key: 'totalprice',
      type: 'number',
      label: 'Total Paid( Rs.)',
    },
    {
      key:'date',
      type:'text',
      label:'Order Date',
      required: true,

    },
    {
      key: 'dispatchdate',
      type: 'string',
      label: 'Dispatch Date',
    },
    {
      key: 'deliverydate',
      type: 'text',
      label: 'Delivery Date',
    },
    {
        key: 'paymentStatus',
        type: 'text',
        label: 'Payment Status',
        required: true
    },
    {
        key: 'orderStatus',
        type: 'text',
        label: 'Order Status',
        required: true
    },
    {
        key: 'isUpdated',
        type: 'isUpdated',
        label: '',
    },
  ];