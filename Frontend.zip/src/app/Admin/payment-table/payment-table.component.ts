import { Component, OnInit, ViewChild, AfterViewInit} from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { PaymentService } from 'src/app/services/payment.service';
import { PaymentColumns, PaymentData } from 'src/app/Utilities/PaymentData';

@Component({
  selector: 'app-payment-table',
  templateUrl: './payment-table.component.html',
  styleUrls: ['./payment-table.component.css']
})
export class PaymentTableComponent implements OnInit,AfterViewInit{
  displayedColumns: string[] = PaymentColumns.map((col) => col.key);
  columnsSchema: any = PaymentColumns;
  dataSource = new MatTableDataSource<PaymentData>();
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;
  constructor(private service: PaymentService) { }

  ngOnInit(): void {
    this.service.getPayment().subscribe((data: any)=>{
      console.log(data);
      this.dataSource.data=data;
    })
  }
  ngAfterViewInit(): void {
    this.dataSource.paginator=this.paginator;
    this.dataSource.sort=this.sort;
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


}
