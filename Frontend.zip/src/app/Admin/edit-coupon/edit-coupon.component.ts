import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { CouponserviceService } from 'src/app/services/couponservice.service';
import { CouponData } from 'src/app/Utilities/CouponData';

@Component({
  selector: 'app-edit-coupon',
  templateUrl: './edit-coupon.component.html',
  styleUrls: ['./edit-coupon.component.css']
})
export class EditCouponComponent implements OnInit {
  rowData: any;
  valid:boolean=true;
  code: string="";
  constructor(@Inject(MAT_DIALOG_DATA) private data: any,private dialogRef: MatDialogRef<EditCouponComponent>,private service: CouponserviceService) { 
    this.rowData=data;
    this.code=this.rowData.code;
  }

  ngOnInit(): void {
  }
  cancelChange(){
    this.dialogRef.close();
  }
  doneChange(){
    this.rowData.code=this.rowData.code.toUpperCase();
    if(this.rowData.code!=this.code){
      this.service.getCouponByName(this.rowData.code).subscribe((data:CouponData[])=>{
        console.log(data);
        if(data.length==0){
          this.valid=true
          this.dialogRef.close(this.rowData);
        }
        else{
          this.valid=false;
        }
      });
    }
    else{
      this.dialogRef.close(this.rowData);
    }
  }


}
