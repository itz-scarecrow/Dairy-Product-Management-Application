export interface Coupon {
    isSelected: boolean;
    id: string;
    code: string;
    discount: number;
    isEdit: boolean;
  }
  
  export const CouponColumns = [
    {
      key: 'isSelected',
      type: 'isSelected',
      label: 'Select',
    },
    {
      key:'code',
      type: 'text',
      label: 'Coupon Code',
      required: true,
    },
    {
      key: 'discount',
      type: 'number',
      label: 'Discount (%)',
      required: true,
    },
    {
      key: 'isEdit',
      type: 'isEdit',
      label: '',
    },
  ];