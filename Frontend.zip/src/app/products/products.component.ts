import { Component, OnInit } from '@angular/core';
import { ProductService } from '../services/product-service.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  prodData: any=[];
  rows: number=0;
  rowNo: any=[];
  prefix:string="../../assets/images/";
  dataid: any;
  id: string="";
  constructor(private router: Router,private service: ProductService) {
    // this.dataid=this.router.getCurrentNavigation()?.extras.state;
    // this.id=this.dataid.data;
    // console.log(this.id);
   }

  ngOnInit(): void {
    this.dataid=JSON.parse(localStorage.getItem('data')|| '{}');
    this.id=this.dataid[0].id;
    console.log(this.id);
    this.service.getProducts().subscribe((data)=>{
      this.prodData=data;
      console.log(this.prodData);
      this.rows=this.prodData.length/3;
      for(let i=0;i<this.rows;i++){
        this.rowNo.push(i);
      }
    })
  }

}
