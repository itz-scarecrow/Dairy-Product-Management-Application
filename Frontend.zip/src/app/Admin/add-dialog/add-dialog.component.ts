import { Component, OnInit , DoCheck} from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-dialog',
  templateUrl: './add-dialog.component.html',
  styleUrls: ['./add-dialog.component.css']
})
export class AddDialogComponent implements OnInit,DoCheck {

  UserData : any={
    id: '',
    imageValue:'',
    imageUrl:'',
    productName: '',
    brandName: '',
    price: 0,
    saleStatus: 'Not On Sale',
    saleValue: 0,
    discountedPrice: 0,
    rating: '2',
    productStatus:'Old',
    description:'',
    category:'Milk'
  }
  obj:any;
  constructor(private dialogRef: MatDialogRef<AddDialogComponent>) { }

  ngOnInit(): void {
  }
  cancelChange(){
    this.dialogRef.close({valid: false,value:this.UserData});
  }
  doneChange(){
    this.dialogRef.close({valid: true,value:this.UserData});
  }
  ngDoCheck(): void {
      if(this.UserData.saleStatus==='Not On Sale'){
        this.UserData.saleValue=0;
        this.UserData.discountedPrice=this.UserData.price;
      }
      else{
        this.UserData.discountedPrice=this.UserData.price-((this.UserData.price*this.UserData.saleValue)/100);
      }
  }
  store(e: Event){
    this.obj= (e.target as HTMLInputElement).files;
    this.UserData.imageValue=(e.target as HTMLInputElement).value;
    this.UserData.imageUrl=this.obj[0].name;
  }

}
