import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-coupon',
  templateUrl: './delete-coupon.component.html',
  styleUrls: ['./delete-coupon.component.css']
})
export class DeleteCouponComponent implements OnInit {

  constructor(private dialogRef: MatDialogRef<DeleteCouponComponent>) { }

  ngOnInit(): void {
  }
  cancelChange(){
    this.dialogRef.close(false);
  }
  doneChange(){
    this.dialogRef.close(true);
  }

}
