export class Cart{
    id: string="";
    userId: string="";
    imageUrl: string="";
    quantity: number=0;
    price: number=0;
    category:string="";
    brandName: string="";
    productname: string="";
}