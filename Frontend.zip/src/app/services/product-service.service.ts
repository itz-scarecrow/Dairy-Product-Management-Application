import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ProductData } from '../Utilities/ProducData';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private serviceUrl: String= 'http://localhost:4400/api';
  constructor(private http: HttpClient) { }

  getProducts(): Observable<ProductData[]> {
    return this.http
      .get(`${this.serviceUrl}/products/get`)
      .pipe<ProductData[]>(map((data: any) => data));
  }

  updateProduct(data: ProductData): Observable<ProductData> {
    console.log(data.id);
    return this.http.put<ProductData>(`${this.serviceUrl}/products/update/${data.id}`, data);
  }

  addProduct(data: ProductData): Observable<ProductData> {
    return this.http.post<any>(`${this.serviceUrl}/products/add`, data);
  }

  deleteProduct(id: number): Observable<any> {
    return this.http.delete<any>(`${this.serviceUrl}/products/delete/${id}`);
  }

  deleteMultipleProducts(datas: ProductData[]): Observable<any> {
    return forkJoin(
      datas.map((data: any) =>
        this.http.delete<any>(`${this.serviceUrl}/products/delete/${data.id}`)
      ));
  }
  getLastestProducts():Observable<any>{
    return this.http.get<any>(`${this.serviceUrl}/products/latest`).pipe<ProductData[]>(map((data: any) => data));
  }
  findProductById(id: string): Observable<ProductData>{
    return this.http.get<ProductData>(`${this.serviceUrl}/product/${id}`)
  }
  findsaleProducts(status:string):Observable<ProductData[]>{
    console.log(status);
    return this.http.get<ProductData[]>(`${this.serviceUrl}/product/bySaleStatus`);

  }
}