import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { CouponserviceService } from 'src/app/services/couponservice.service';
import { CouponData } from 'src/app/Utilities/CouponData';

@Component({
  selector: 'app-add-coupon',
  templateUrl: './add-coupon.component.html',
  styleUrls: ['./add-coupon.component.css']
})
export class AddCouponComponent implements OnInit {
  CouponData : any={
    id: '',
    code:'',
    discount:0
  }
  valid:boolean= true;
  constructor(private dialogRef: MatDialogRef<AddCouponComponent>,private service: CouponserviceService) { }

  ngOnInit(): void {
  }
  cancelChange(){
    this.dialogRef.close({valid: false,value:this.CouponData});
  }
  doneChange(){
    this.CouponData.code=this.CouponData.code.toUpperCase();
    this.service.getCouponByName(this.CouponData.code).subscribe((data:CouponData[])=>{
      console.log(data);
      if(data.length==0){
        this.valid=true
        this.dialogRef.close({valid: true,value:this.CouponData});
      }
      else{
        this.valid=false;
      }
    })
  }

}
