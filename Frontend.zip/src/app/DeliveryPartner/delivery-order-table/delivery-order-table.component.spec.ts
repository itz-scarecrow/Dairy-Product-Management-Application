import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeliveryOrderTableComponent } from './delivery-order-table.component';

describe('DeliveryOrderTableComponent', () => {
  let component: DeliveryOrderTableComponent;
  let fixture: ComponentFixture<DeliveryOrderTableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DeliveryOrderTableComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DeliveryOrderTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
