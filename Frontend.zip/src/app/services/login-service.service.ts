import { ObserversModule } from '@angular/cdk/observers';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable,catchError,retry,throwError } from 'rxjs';
import { LogIn } from '../Utilities/LogIn';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {
  verifyUrl: String='http://localhost:4400/api';
  isLoggedIn: boolean=false;
  role: String="";
  userdata: LogIn={
    id:"",
    username: "",
    email: "",
    password: "",
    roles: ""
  }
  constructor(private http: HttpClient) { }
  getDeatilsWithUserName(email: String, Roles:String):Observable<LogIn[]>{
    console.log("email"+" "+"Roles");
    return this.http.get<LogIn[]>(`${this.verifyUrl}/verify/${email}/${Roles}`).pipe(retry(1),catchError(this.handleError));
  }
  postDetails(data: any): Observable<LogIn>{
    return this.http.post<LogIn>(`${this.verifyUrl}/register`,data).pipe(retry(1),catchError(this.handleError));
  }
  getDetailsWithId(id:string):Observable<LogIn>{
    return this.http.get<LogIn>(`${this.verifyUrl}/get/${id}`);
  }
  handleError(er: any){
    return throwError(()=>{
      console.log(er);
    })
  }
}
