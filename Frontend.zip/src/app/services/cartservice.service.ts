import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { forkJoin, Observable } from 'rxjs';
import { Cart } from '../Utilities/Cart';

@Injectable({
  providedIn: 'root'
})
export class CartserviceService {
  cartData: Cart[]=[];
  private url: string = "http://localhost:4400/api";
  constructor(private http:HttpClient) { }
  addInCart(data:Cart): Observable<Cart[]> {
    return this.http.post<Cart[]>(`${this.url}/cart/add`, data)
  }
  addMultipleInCart(datas: Cart[]): Observable<any> {
    console.log(datas);
    return forkJoin(
      datas.map((data: any) =>
        this.http.post<any>(`${this.url}/cart/add`,data))
      );
  }
  getCartData(userid:String):Observable<Cart[]>{
    return this.http.get<Cart[]>(`${this.url}/cart/get/${userid}`);
  }
  changeQuantity(id: string,quantity:number):Observable<Cart>{
    return this.http.post<Cart>(`${this.url}/chngQuantity/${id}`,quantity);
  }
  deleteCartData(id: string){
    return this.http.delete<Cart>(`${this.url}/delete/${id}`);
  }
  deleteMultipleCartItems(datas: any): Observable<any> {
    return forkJoin(
      datas.map((data: any) =>
        this.http.delete<any>(`${this.url}/delete/${data.id}`)
      ));
  }
  showCartData(data: Cart[]){
    console.log(data);
    this.cartData=data;
  }
  returnCartData(): Cart[]{
    return this.cartData;
  }
}
